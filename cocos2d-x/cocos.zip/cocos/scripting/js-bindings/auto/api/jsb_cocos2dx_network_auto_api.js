/**
 * @module network
 */
var jsb = jsb || {};

/**
 * @class Downloader
 */
jsb.Downloader = {

/**
 * @method setOnTaskProgress
 * @param {function} arg0
 */
setOnTaskProgress : function (
func 
)
{
},

/**
 * @method Downloader
 * @constructor
* @param {cc.network::DownloaderHints} downloaderhints
*/
Downloader : function(
downloaderhints 
)
{
},

};
